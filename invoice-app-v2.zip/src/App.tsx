import { CreateInvoice } from './pages/CreateInvoice';

function App() {
  return <CreateInvoice />;
}

export default App;
