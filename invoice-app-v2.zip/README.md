# System Faktur v2.0

System do wystawiania faktur VAT i proform z integracją KSeF.

## Zmiany w wersji 2.0

### Nowe funkcjonalności:
1. **Moduł KSeF** - Krajowy System e-Faktur
   - Konfiguracja środowiska (test/produkcja) i tokenu autoryzacyjnego
   - Wysyłanie faktur VAT do KSeF
   - Sprawdzanie statusu wysłanych faktur
   - Pobieranie numerów KSeF i UPO

2. **Panel zarządzania w sidebar** - wszystko w jednym miejscu
   - Zakładka "Faktura" - tworzenie nowych dokumentów
   - Zakładka "Firma" - edycja danych wystawcy
   - Zakładka "Odbiorcy" - zarządzanie bazą klientów
   - Zakładka "Dokumenty" - historia faktur i proform
   - Zakładka "KSeF" - integracja z Krajowym Systemem e-Faktur

3. **Auto-dodawanie nabywców** 
   - Przy zapisie faktury, jeśli nabywca nie istnieje w bazie (sprawdzanie po NIP), zostaje automatycznie dodany

4. **Wyszukiwarka lokalna odbiorców**
   - Usunięto mock KRS
   - Wyszukiwanie odbywa się w lokalnej bazie odbiorców
   - Wyszukiwanie po nazwie, NIP lub mieście

### Usunięte:
- Strona `/manage` - funkcjonalność przeniesiona do sidebara
- Mock wyszukiwarki KRS - zastąpiony wyszukiwarką lokalną
- React Router - nie jest już potrzebny (single page)

## Instalacja

```bash
npm install
npm run dev
```

## Struktura projektu

```
src/
├── components/
│   ├── buyers/
│   │   ├── BuyerForm.tsx      # Formularz nabywcy
│   │   └── BuyerSearch.tsx    # Wyszukiwarka lokalna
│   ├── invoices/
│   │   └── InvoicePreview.tsx # Podgląd faktury
│   ├── ksef/
│   │   └── KSeFPanel.tsx      # Panel KSeF
│   ├── layout/
│   │   └── Sidebar.tsx        # Główny sidebar z zakładkami
│   ├── seller/
│   │   ├── SellerForm.tsx     # Formularz sprzedawcy
│   │   └── SellerSetupModal.tsx
│   └── ui/
│       ├── Button.tsx
│       ├── Collapsible.tsx
│       ├── Input.tsx
│       └── Modal.tsx
├── pages/
│   └── CreateInvoice.tsx      # Główna strona
├── services/
│   └── ksefService.ts         # Serwis KSeF API
├── store/
│   └── invoiceStore.ts        # Zustand store
├── types/
│   ├── invoice.ts
│   ├── ksef.ts
│   └── seller.ts
└── utils/
    ├── calculations.ts
    ├── exporter.ts
    ├── formatting.ts
    ├── storage.ts
    └── validation.ts
```

## Technologie

- React 18
- TypeScript
- Vite
- Tailwind CSS
- Zustand (state management)
